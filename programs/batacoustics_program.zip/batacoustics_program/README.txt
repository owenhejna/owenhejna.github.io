Hello! Thank you for downloading the materials for my bat acoustics educational program. The goal of this program is to educate students about Illinois bat species, echolocation, acoustic monitoring, and acoustic bat call identification. This is generally a higher level program meant for high school aged students or adults. The program is presentation-based and includes a general introduction to the afore-mentioned topics as well as a bat call identification game towards the end of the slides. A acoustic ID guide is also included to give as a handout during the game. 

File descriptions
illinoisbatacoustics_slidedeck.pptx: The slidedeck for leading this program. General curriculum can be viewed in the speaker notes for each slide. The latter half of this slide deck is made up of slides to train the participants for the game and the game itself. Again, this is a rather high level program so consider your audience carefully. Feel free to email ohejna@outlook.com if you have any questions.
illinoisbatacoustics_slidedeck.pdf: Same as above, just in a pdf form
batacoustics_guide.docx:T This is a guide containing most of the acoustically relevant information you went over in the program. You went over a LOT of info so this should help them correctly ID calls when it comes time for the game. Print as hand out before game.
batacoustics_guide.pdf: Same as above, just in a pdf form
LICENSE.txt: An open-source license that prevents anyone from redistributing this program under a different name. This license is NOT meant to restrict use, only to prevent program creation from being credited to anyone besides Owen Hejna.

