# ============================================================
# Bio Blitz Results Visualizer
#
# SETUP: Before running, set your working directory to the folder
# containing your CSV file:
#   setwd("path/to/your/folder")
#
# Rename your CSV to "bigsit_results.csv" or update the filename below.
# ============================================================
setwd("/path/to/your/bioblitz_program")

# load in necessary libraries
library(tidyverse)

# Read in the CSV
df <- read_csv("bioblitz_results.csv")

# define colors for taxonomic groups (from iNat)
taxon_colors <- c(
  "Plantae" = "#73AC13",     # Green
  "Insecta" = "#FF8300",     # Orange
  "Arachnida" = "#AA0078",   # Purple
  "Mammalia" = "#D73F3F",    # Red
  "Fungi" = "#A8A8A8",       # Gray
  "Mollusca" = "#00B3A6",    # Teal
  "Isopoda" = "#007BA7"      # Blue/Crustaceans
)

# prepare data for pie chart
taxon_data <- df %>%
  count(iconic_taxon_name) %>%
  arrange(desc(n)) %>%
  mutate(
    percent = n / sum(n) * 100,
    label = paste0(iconic_taxon_name, " (", round(percent, 1), "%)")
  )

# create pie chart for total observations by taxonomic group
ggplot(taxon_data, aes(x = "", y = n, fill = iconic_taxon_name)) +
  geom_col(width = 1, color = "black") +
  coord_polar(theta = "y") +
  scale_fill_manual(values = taxon_colors) +
  theme_void() +
  labs(title = "# of Observations by Taxonomic Group") +
  theme(
    legend.title = element_blank(),
    legend.position = "bottom"
  ) +
  guides(fill = guide_legend(reverse = TRUE))

# Group data by site and taxonomic group
taxon_by_site <- df %>%
  count(place_guess, iconic_taxon_name)

# Get unique site names
unique_sites <- unique(taxon_by_site$place_guess)

# Loop through each site and generate a plot
plots <- map(unique_sites, function(site) {
  site_data <- taxon_by_site %>% filter(place_guess == site)
  
  ggplot(site_data, aes(x = iconic_taxon_name, y = n, fill = iconic_taxon_name)) +
    geom_col(color = "black", width = 0.7) +
    scale_fill_manual(values = taxon_colors) +
    labs(
      title = paste("# Observations by Taxonomic Group at", site),
      x = "Taxonomic Group",
      y = "# Observations"
    ) +
    coord_cartesian(ylim = c(0, 70)) +
    theme_minimal() +
    theme(
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      legend.position = "none",
      panel.background = element_rect(fill = "#fffff0", color = NA),
      plot.background = element_rect(fill = "#fffff0", color = NA)
    )
})

# Display plots, use the arrows in the top right to see them all!
walk(plots, print)


