Hello! Thank you for downloading the materials for my watershed role playing program. The goal of this program is to educate students about the importance of watersheds and how human activities can severely impact them through interactive group-centered role play.

File descriptions
instructions.pdf: This file contains the instructions for the teacher on how to set up and run the role playing activity in the classroom.
cards.pdf: This file contains the role play choice cards that students will use during the activity. Each card is a different decision that the students must make as part of their role in the watershed. There are 4 different roles within the game: farmer, industrialist, family, and politician. The cards will need to but cut from this paper, there are 16 cards total 4 for each group.
answersheet.pdf: This file has the correct answer for every decision made for all four groups. This file also contains information about what is to be done to the "watershed" based on what decision the student group chooses. This file also contains the budget amounts and costs for certain choices.
money.pdf: Exactly $1700 is needed to fulfill each group budget. This file contains enough cutouts for $2000 in case some goes missing or gets wet.
LICENSE.txt: An open-source license that prevents anyone from redistributing this program under a different name. This license is NOT meant to restrict use, only to prevent program creation from being credited to anyone besides Owen Hejna.
README.txt: A brief description of the program and accompanied files. You're reading it!